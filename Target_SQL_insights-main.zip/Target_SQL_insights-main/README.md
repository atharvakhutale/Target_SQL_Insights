# Target_SQL_insights
Analyzed 100k orders from 2016-2018 for Target in Brazil. Insights on order processing, pricing, payment/shipping efficiency, customer demographics, product attributes, and satisfaction. Enhanced operations for exceptional value and guest experience.
